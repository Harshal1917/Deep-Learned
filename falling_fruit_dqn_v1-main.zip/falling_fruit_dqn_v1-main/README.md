# falling_fruit_dqn_v1
Deep Reinforcement Learning with simple falling fruit game

Full details here: https://medium.com/@www.seymour/training-an-ai-to-play-a-game-using-deep-reinforcement-learning-b63534cfdecd
